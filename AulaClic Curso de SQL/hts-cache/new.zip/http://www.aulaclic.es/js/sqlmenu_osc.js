

	var NoOffFirstLineMenus=9;			

	var LowBgColor="fff6ec";			

	var HighBgColor="lightblue";		

	var FontLowColor="yellow";

	var FontHighColor="blue";		

	var BorderColor="800000";

	var BorderWidth=0;				

	var BorderBtwnElmnts=1;

	var FontFamily="verdana,arial,technical";	

	var FontSize=8;

	var FontBold=1;				

	var FontItalic=0;

	var MenuTextCentered="left";		

	var MenuCentered="left";

	var MenuVerticalCentered="top";		

	var ChildOverlap=.05;

	var ChildVerticalOverlap=.1;			

	var StartTop=28;

	var StartLeft=160;

	var VerCorrect=0;

	var HorCorrect=0;

	var LeftPaddng=3;				

	var TopPaddng=2;

	var FirstLineHorizontal=1;			

	var MenuFramesVertical=0;

	var DissapearDelay=500;			

	var UnfoldDelay=10;	

	var TakeOverBgColor=1;			

	var FirstLineFrame="topFrame";

	var SecLineFrame="mainFrame";		

	var DocTargetFrame="mainFrame";		

	var TargetLoc="";

	var MenuWrap=1;				

	var RightToLeft=0;

	var BottomUp=0;				

	var UnfoldsOnClick=0;

	var BaseHref="";			



	var Arrws=[BaseHref+"tri.gif",15,10,BaseHref+"tridown.gif",1,5,BaseHref+"trileft.gif",5,10,BaseHref+"triup.gif",10,5];



	var MenuUsesFrames=1;	



	var RememberStatus=0;

	var PartOfWindow=.9;				

	var MenuSlide="";

	var MenuSlide="progid:DXImageTransform.Microsoft.RevealTrans(duration=.5, transition=19)";

	var MenuSlide="progid:DXImageTransform.Microsoft.GradientWipe(duration=.5, wipeStyle=1)";



	var MenuShadow="";



	var MenuOpacity="";

	function BeforeStart(){return}

	function AfterBuild(){return}

	function BeforeFirstOpen(){return}

	function AfterCloseAll(){return}





Menu1=new Array("<img src='"+BaseHref+"comunes/vista_6_izq.gif' align='center'>","javascript:top.location.href='index.htm'","",0,35,6,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

Menu2=new Array("rollover?"+BaseHref+"comunes/vista_6a_sql.gif?"+BaseHref+"comunes/vista_6_sql.gif","javascript:top.location.href='index.htm'","",10,35,91,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

	Menu2_1=new Array("Indice detallado","index.htm","",0,18,195,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");

	Menu2_2=new Array("1. Introducci�n","t_1_1.htm","",0,18,195,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");

	Menu2_3=new Array("2. Las consultas simples","t_2_1.htm","",0,18,170,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");

	Menu2_4=new Array("3. Las consultas multitabla","t_3_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu2_5=new Array("4. Las consultas resumen","t_4_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu2_6=new Array("5. Las subconsultas","t_5_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu2_7=new Array("6. Actualizaci�n de datos","t_6_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu2_8=new Array("7. Referencias cruzadas","t_7_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu2_9=new Array("8. El DDL","t_8_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");

	Menu2_10=new Array("Ejercicios propuestos","epr_2_1.htm","",0,18,100,"f9e8c5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

Menu3=new Array("rollover?"+BaseHref+"comunes/vista_5_central_1.gif?"+BaseHref+"comunes/vista_6a_central_1.gif","javascript:top.location.href='../index.htm'","",19,35,85,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

	Menu3_1=new Array("Autocad 2008","javascript:top.location.href='/autocad2008/index.htm'","",0,20,115,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_2=new Array("Access 2007","javascript:top.location.href='/access2007/index.htm'","",0,20,115,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_3=new Array("CorelDraw X5","javascript:top.location.href='/coreldraw-x5/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_4=new Array("Dreamweaver CS5","javascript:top.location.href='../dreamweaver-cs5/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_5=new Array("Excel 2010","javascript:top.location.href='/excel2010/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_6=new Array("Flash CS4","javascript:top.location.href='/flash-cs4/index.htm'","",0,20,110,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_7=new Array("FrontPage2003","javascript:top.location.href='/frontpage2003/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_8=new Array("Google Docs","javascript:top.location.href='/googledocs/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_9=new Array("HTML","javascript:top.location.href='/html/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_10=new Array("Illustrator CS4","javascript:top.location.href='/illustrator-cs4/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_11=new Array("Internet","javascript:top.location.href='/internet/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_12=new Array("OpenOffice","javascript:top.location.href='/openoffice/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_13=new Array("Outlook2007","javascript:top.location.href='/outlook2007/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_14=new Array("Photoshop CS5","javascript:top.location.href='/photoshop-cs5/index.htm'","",0,20,110,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_15=new Array("PowerPoint2007","javascript:top.location.href='/power2007/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_16=new Array("SQL","javascript:top.location.href='/sql/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_17=new Array("Word 2007","javascript:top.location.href='/word2007/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_18=new Array("Windows 7","javascript:top.location.href='/windows7/index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu3_19=new Array("Mas cursos...","javascript:top.location.href='../index.htm'","",0,20,100,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

Menu4=new Array("rollover?"+BaseHref+"comunes/vista_5_central_opc.gif?"+BaseHref+"comunes/vista_6a_central_opc.gif","javascript:top.location.href='../index.htm'","",5,35,85,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

	Menu4_1=new Array("Selecci�n cursos","javascript:top.location.href='http://www.aulaclic.net/cursos/'","",0,20,160,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu4_2=new Array("Art�culos","javascript:top.location.href='../articulos/index.html'","",0,20,110,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu4_3=new Array("Foros","javascript:top.location.href='http://www.aulaclic.net/user/'","",0,20,110,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu4_4=new Array("Comprar","javascript:top.location.href='curso_pago.htm'","",0,20,110,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	

	Menu4_5=new Array("Preguntas m�s frecuentes","javascript:top.location.href='http://www.aulaclic.es/portada/faqs.htm'","",0,20,160,"F9E8C5","800000","800000","fff6ec","800000",-1,-1,-1,"","");	



Menu5=new Array("rollover?"+BaseHref+"comunes/vista_5_retroceder.gif?"+BaseHref+"comunes/vista_5a_retroceder.gif","javascript:irAnterior()","",0,35,51,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

Menu6=new Array("rollover?"+BaseHref+"comunes/vista_5_avanzar.gif?"+BaseHref+"comunes/vista_5a_avanzar.gif","javascript:irSiguiente()","",0,35,51,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

Menu7=new Array("rollover?"+BaseHref+"comunes/vista_5_ayuda.gif?"+BaseHref+"comunes/vista_5a_ayuda.gif","javascript:top.location.href='informacion.htm'","",0,35,51,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

Menu8=new Array("rollover?"+BaseHref+"comunes/vista_5_home.gif?"+BaseHref+"comunes/vista_6a_home.gif","javascript:top.location.href='../index.htm'","",0,35,51,"F5E4C4","800000","800000","fff6ec","F5E4C4",-1,-1,-1,"","");

Menu9=new Array("<img src='"+BaseHref+"comunes/vista_6_der.gif'>","index.htm","",0,35,6,"F5E4C4","800000","800000","fff6ec","800000",-1,-1,-1,"","");



function irAnterior(){

var currPage = location;

	if (previous != "end"){

		currPage.href = eval('"' + previous + '"');

	}

	else{

			alert('No se puede retroceder. Es la primera pagina.');

	}

}



function irSiguiente(){

var currPage = location;

	if (next != "end"){

		currPage.href = eval('"' + next + '"');

	}

	else{

			alert('No se puede avanzar. Es la �ltima pagina');

	}

}





function iSg(){

mURL= 'index.htm';

var currPage = location;

	tuvector = location.href.split("/");

	if (tuvector[0]!="http:"){

	   currPage.href = eval('"' + mURL + '"');}}

	

function mostrar(page)

	{

	var newWin;

	newWin = window.open(page, 'infowin', 'width=660,height=500,scrolling=no,toolbars=no,menubar=no,location=no,directories=no,resizeable=no');

	}

function aviso(page)

	{

	var newWin;

	newWin = window.open(page, 'infowin', 'width=300,height=150,scrolling=no,toolbars=no,menubar=no');}

